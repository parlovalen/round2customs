/* 8-bit CNC gantry router — pixel scene set for animations-v2 SceneStage.
   Grid: 80x80 logical pixels rendered as SVG rects (crisp, chunky NES-era). */

const PX = 12;
const G = 80;
const SIZE = G * PX; // 960

const C = {
  bg: '#000000',
  frame: '#1F1F22',
  frameHi: '#3A3A42',
  hair: '#2A2A2E',
  bed: '#141416',
  slat: '#0B0B0D',
  steelHi: '#5A5A64',
  steel: '#3A3A42',
  steelLo: '#22222A',
  steelShadow: '#141418',
  wood: '#B3854A',
  woodHi: '#C9A067',
  woodLo: '#8E6636',
  woodEdge: '#6B4B27',
  groove: '#3A2712',
  orange: '#E15A2B',
  hot: '#FF7A45',
  cyan: '#2EB6E0',
  yellow: '#F5C518',
  magenta: '#D63384',
};

/* ── geometry ───────────────────────────────────────────────────────────── */

const BED = { x: 8, y: 8, w: 64, h: 61 };
const SHEET = { x: 14, y: 12, w: 53, h: 53 };
const POLY = [[26, 22], [54, 22], [58, 26], [58, 54], [54, 58], [26, 58], [22, 54], [22, 26], [26, 22]];
const HOME = { x: 17, y: 10 };
const HOME_CAM = { cx: 40, cy: 40, z: 1 };
const CUT_Z = 1.5;

function bres(x0, y0, x1, y1) {
  const out = [];
  let dx = Math.abs(x1 - x0), dy = Math.abs(y1 - y0);
  let sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1;
  let err = dx - dy, x = x0, y = y0;
  for (;;) {
    out.push([x, y]);
    if (x === x1 && y === y1) break;
    const e2 = 2 * err;
    if (e2 > -dy) { err -= dy; x += sx; }
    if (e2 < dx) { err += dx; y += sy; }
  }
  return out;
}

const PATH = (() => {
  const pts = [];
  for (let i = 0; i < POLY.length - 1; i++) {
    const seg = bres(POLY[i][0], POLY[i][1], POLY[i + 1][0], POLY[i + 1][1]);
    for (let j = 0; j < seg.length; j++) {
      if (i > 0 && j === 0) continue;
      pts.push(seg[j]);
    }
  }
  return pts;
})();
const PATH_N = PATH.length;

const cutU = interpolate([0, 0.08, 0.92, 1], [0, 0.06, 0.94, 1], Easing.easeInOutCubic);
function bitAtU(u) {
  const i = Math.max(0, Math.min(PATH_N - 1, Math.round(u * (PATH_N - 1))));
  return { x: PATH[i][0], y: PATH[i][1], i };
}
/* progress-based camera target so it survives user retiming */
function cutCam(p) {
  let sx = 0, sy = 0;
  const N = 5;
  for (let k = 0; k < N; k++) {
    const q = Math.max(0, Math.min(1, p - 0.07 * (k / (N - 1))));
    const b = bitAtU(cutU(q));
    sx += b.x; sy += b.y;
  }
  return { cx: sx / N, cy: sy / N, z: CUT_Z };
}

function viewBox(cam) {
  const z = Math.round(cam.z * 20) / 20;
  const s = G / z;
  const half = s / 2;
  const cx = Math.min(G - half, Math.max(half, cam.cx));
  const cy = Math.min(G - half, Math.max(half, cam.cy));
  const q = (v) => Math.round(v * 2) / 2;
  return `${q(cx - half)} ${q(cy - half)} ${s} ${s}`;
}
const lerp = (a, b, t) => a + (b - a) * t;
function lerpCam(a, b, t) {
  return { cx: lerp(a.cx, b.cx, t), cy: lerp(a.cy, b.cy, t), z: lerp(a.z, b.z, t) };
}

/* ── pixel helpers ──────────────────────────────────────────────────────── */

function R(key, x, y, w, h, fill, opacity) {
  return React.createElement('rect', { key, x, y, width: w, height: h, fill, opacity });
}
const P = (key, x, y, fill, o) => R(key, x, y, 1, 1, fill, o);

function woodRowColor(y) {
  const m = ((y * 5) % 11 + 11) % 11;
  if (m === 0 || m === 6) return C.woodHi;
  if (m === 3 || m === 8) return C.woodLo;
  return C.wood;
}

function Sheet({ trail }) {
  const rows = [];
  for (let y = SHEET.y; y < SHEET.y + SHEET.h; y++) {
    rows.push(R('w' + y, SHEET.x, y, SHEET.w, 1, woodRowColor(y)));
    const k = ((y * 13) % 7 + 7) % 7;
    if (k < 3) rows.push(P('g' + y, SHEET.x + 3 + ((y * 17) % (SHEET.w - 6)), y, C.woodEdge, 0.5));
  }
  rows.push(R('we', SHEET.x, SHEET.y, 1, SHEET.h, C.woodEdge));
  rows.push(R('wb', SHEET.x, SHEET.y + SHEET.h - 1, SHEET.w, 1, C.woodEdge));
  rows.push(R('wt', SHEET.x, SHEET.y, SHEET.w, 1, C.woodHi, 0.7));
  return React.createElement('g', null, rows, trail);
}

function Trail({ count }) {
  if (count <= 0) return null;
  const n = Math.min(PATH_N, count);
  const out = [];
  for (let i = 0; i < n; i++) {
    const [x, y] = PATH[i];
    out.push(P('t' + i, x, y, C.groove));
    if (i % 3 === 0) out.push(P('td' + i, x + 1, y, C.woodEdge, 0.55));
  }
  return React.createElement('g', null, out);
}

function Bed() {
  const el = [];
  el.push(R('bed', BED.x, BED.y, BED.w, BED.h, C.bed));
  for (let x = BED.x + 3; x < BED.x + BED.w; x += 6) el.push(R('s' + x, x, BED.y, 1, BED.h, C.slat));
  for (let y = BED.y + 4; y < BED.y + BED.h; y += 8) el.push(R('h' + y, BED.x, y, BED.w, 1, C.slat, 0.6));
  return React.createElement('g', null, el);
}

function Frame() {
  const el = [];
  el.push(R('o', 4, 4, 72, 72, C.frame));
  el.push(R('oh', 4, 4, 72, 1, C.frameHi));
  el.push(R('os', 4, 75, 72, 1, '#0d0d0f'));
  el.push(R('in', 6, 6, 68, 66, C.hair));
  // vertical rails the gantry rides
  for (const rx of [6, 71]) {
    el.push(R('r' + rx, rx, 7, 2, 63, C.steel));
    el.push(R('rh' + rx, rx, 7, 1, 63, C.steelHi, 0.8));
    for (let y = 9; y < 69; y += 4) el.push(P('rt' + rx + y, rx + 1, y, C.steelLo));
  }
  // apron + rainbow decal
  el.push(R('ap', 6, 69, 68, 3, C.frame));
  const stripe = [C.orange, C.yellow, C.cyan, C.magenta];
  for (let i = 0; i < 4; i++) el.push(R('st' + i, 9 + i * 4, 70, 3, 1, stripe[i]));
  el.push(R('badge', 60, 70, 11, 1, C.steelLo));
  return React.createElement('g', null, el);
}

function Gantry({ bx, by, lift, spin, accent }) {
  const el = [];
  // beam
  el.push(R('b1', 6, by - 2, 68, 1, C.steelHi));
  el.push(R('b2', 6, by - 1, 68, 1, C.steel));
  el.push(R('b3', 6, by, 68, 1, C.steelLo));
  el.push(R('b4', 6, by + 1, 68, 1, C.steelShadow, 0.9));
  el.push(R('b5', 6, by + 2, 68, 1, '#000', 0.35));
  // end trucks
  for (const ex of [6, 70]) el.push(R('e' + ex, ex, by - 3, 4, 6, C.steel));
  for (const ex of [6, 70]) el.push(R('eh' + ex, ex, by - 3, 4, 1, C.steelHi));
  // carriage
  const cx0 = bx - 3;
  el.push(R('c1', cx0, by - 6, 7, 5, C.steel));
  el.push(R('c2', cx0, by - 6, 7, 1, C.steelHi));
  el.push(R('c3', cx0, by - 6, 1, 5, C.steelHi, 0.8));
  el.push(R('c4', cx0 + 6, by - 6, 1, 5, C.steelShadow));
  el.push(P('led1', cx0 + 1, by - 5, accent));
  el.push(P('led2', cx0 + 5, by - 5, C.cyan));
  el.push(R('c5', cx0 + 1, by - 4, 5, 1, C.steelLo));
  // spindle nose
  const ny = by + 1 - lift;
  el.push(R('n1', bx - 2, ny - 1, 5, 2, C.steelHi));
  el.push(R('n2', bx - 1, ny + 1, 3, 1, C.steel));
  el.push(P('n3', bx, ny + 2, spin ? '#FFE6D6' : C.steelLo));
  return React.createElement('g', null, el);
}

function Glow({ bx, by, on, accent, t }) {
  if (!on) return null;
  const f = 0.75 + 0.25 * Math.sin(t * 22);
  return React.createElement('g', null, [
    R('g3', bx - 3, by - 3, 7, 7, accent, 0.08 * f),
    R('g2', bx - 2, by - 2, 5, 5, accent, 0.16 * f),
    R('g1', bx - 1, by - 1, 3, 3, C.hot, 0.3 * f),
    P('g0', bx, by, f > 0.85 ? '#FFF3E6' : C.hot),
    P('sp1', bx + (f > 0.9 ? 1 : -1), by - 1, C.yellow, 0.9),
  ]);
}

function hash(n) { const s = Math.sin(n * 127.1 + 311.7) * 43758.5453; return s - Math.floor(s); }

function Chips({ p, count }) {
  if (count <= 0) return null;
  const life = 0.07, out = [];
  for (let k = 0; k < count; k++) {
    const spawn = (k / count) * (1 + life);
    const a = (p - spawn) / life;
    if (a < 0 || a > 1) continue;
    const b = bitAtU(cutU(Math.min(1, spawn)));
    const vx = (hash(k) - 0.5) * 11;
    const arc = -5.5 - hash(k + 9) * 3;
    const x = Math.round(b.x + vx * a);
    const y = Math.round(b.y + arc * a + 9 * a * a);
    out.push(P('c' + k, x, y, k % 3 === 0 ? C.yellow : C.woodHi, 1 - a * 0.5));
  }
  return React.createElement('g', null, out);
}

function Scanlines() {
  const el = [];
  for (let y = 0; y < G; y += 2) el.push(R('sl' + y, 0, y, G, 1, '#000', 0.14));
  return React.createElement('g', { style: { pointerEvents: 'none' } }, el);
}

/* ── the persistent stage: every scene renders this same machine ────────── */

function Machine(props) {
  const {
    cam, bx, by, lift, spin, glow, trailCount, chipsP, chipCount,
    oldDX, newDX, showNew, pieceDY, pieceOpacity, tweaks, t,
  } = props;
  const accent = tweaks.accent;
  const clipId = 'bedclip';
  const holeOpen = pieceDY > 0 || pieceOpacity < 1;
  return (
    <svg width="100%" height="100%" viewBox={viewBox(cam)}
         shapeRendering="crispEdges" style={{ display: 'block', background: C.bg }}>
      <defs>
        <clipPath id={clipId}>
          <rect x={BED.x} y={BED.y} width={BED.w} height={BED.h} />
        </clipPath>
        <clipPath id="piececlip">
          <polygon points={POLY.map((q) => q.join(',')).join(' ')} />
        </clipPath>
      </defs>
      <rect x={0} y={0} width={G} height={G} fill={C.bg} />
      <Frame />
      <Bed />
      <g clipPath={`url(#${clipId})`}>
        <g transform={`translate(${Math.round(oldDX)} 0)`}>
          {holeOpen ? (
            <g>
              <Sheet />
              <g clipPath="url(#piececlip)">
                <rect x={BED.x} y={BED.y} width={BED.w} height={BED.h} fill="#08080A" />
                {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((i) => (
                  <rect key={'hs' + i} x={BED.x + 3 + i * 6} y={BED.y} width={1} height={BED.h} fill={C.steelLo} />
                ))}
              </g>
              <g transform={`translate(0 ${Math.round(pieceDY)})`} opacity={pieceOpacity}>
                <g clipPath="url(#piececlip)"><Sheet /></g>
              </g>
              <Trail count={trailCount} />
            </g>
          ) : (
            <g><Sheet /><Trail count={trailCount} /></g>
          )}
        </g>
        {showNew && (
          <g transform={`translate(${Math.round(newDX)} 0)`}><Sheet /></g>
        )}
      </g>
      <Chips p={chipsP} count={chipCount} />
      <Gantry bx={bx} by={by} lift={lift} spin={spin} accent={accent} />
      {tweaks.glow && <Glow bx={bx} by={by} on={glow} accent={accent} t={t} />}
      {tweaks.scanlines && <Scanlines />}
    </svg>
  );
}

/* ── scenes ─────────────────────────────────────────────────────────────── */

const TweakCtx = React.createContext({ accent: C.orange, chips: 22, glow: true, scanlines: true });
const useT = () => React.useContext(TweakCtx);

function Approach() {
  const { progress: p, localTime } = useScene();
  const tweaks = useT();
  const start = bitAtU(0);
  const by = Math.round(lerp(HOME.y, start.y, Easing.easeInOutCubic(clamp((p - 0.12) / 0.5, 0, 1))));
  const bx = Math.round(lerp(HOME.x, start.x, Easing.easeInOutCubic(clamp((p - 0.34) / 0.55, 0, 1))));
  const spinUp = clamp((p - 0.65) / 0.3, 0, 1);
  const cam = lerpCam(HOME_CAM, cutCam(0), Easing.easeInOutCubic(clamp((p - 0.08) / 0.92, 0, 1)));
  return (
    <Machine cam={cam} bx={bx} by={by} lift={Math.round(2 * (1 - spinUp))} spin={spinUp > 0.5}
             glow={spinUp > 0.6} trailCount={0} chipsP={-1} chipCount={0}
             oldDX={0} newDX={0} showNew={false} pieceDY={0} pieceOpacity={1}
             tweaks={tweaks} t={localTime} />
  );
}

function Cut() {
  const { progress: p, localTime } = useScene();
  const tweaks = useT();
  const u = cutU(p);
  const b = bitAtU(u);
  return (
    <Machine cam={cutCam(p)} bx={b.x} by={b.y} lift={0} spin
             glow trailCount={b.i + 1} chipsP={p} chipCount={tweaks.chips}
             oldDX={0} newDX={0} showNew={false} pieceDY={0} pieceOpacity={1}
             tweaks={tweaks} t={localTime} />
  );
}

function Eject() {
  const { progress: p, localTime } = useScene();
  const tweaks = useT();
  const end = bitAtU(1);
  const lift = Math.round(2 * Easing.easeOutCubic(clamp(p / 0.14, 0, 1)));
  // head retreats home
  const rx = Easing.easeInOutCubic(clamp((p - 0.58) / 0.36, 0, 1));
  const ry = Easing.easeInOutCubic(clamp((p - 0.68) / 0.3, 0, 1));
  const bx = Math.round(lerp(end.x, HOME.x, rx));
  const by = Math.round(lerp(end.y, HOME.y, ry));
  // part drops out
  const d = clamp((p - 0.26) / 0.3, 0, 1);
  const pieceDY = d * d * 74;
  // stock feed: old sheet out left, fresh sheet in from right
  const feed = Easing.easeInOutCubic(clamp((p - 0.56) / 0.34, 0, 1));
  const oldDX = -feed * 60;
  const newDX = (1 - feed) * 60;
  const cam = lerpCam(cutCam(1), HOME_CAM, Easing.easeInOutCubic(clamp((p - 0.04) / 0.38, 0, 1)));
  return (
    <Machine cam={cam} bx={bx} by={by} lift={lift} spin={p < 0.2} glow={p < 0.12}
             trailCount={PATH_N} chipsP={-1} chipCount={0}
             oldDX={oldDX} newDX={feed > 0 ? newDX : 60} showNew={feed > 0}
             pieceDY={pieceDY} pieceOpacity={1}
             tweaks={tweaks} t={localTime} />
  );
}

/* ── root ───────────────────────────────────────────────────────────────── */

function CncRoot() {
  const [tw, setTweak] = useTweaks(window.TWEAK_DEFAULTS || {});
  const tweaks = {
    accent: tw.accent || C.orange,
    chips: tw.chips == null ? 22 : tw.chips,
    glow: tw.glow !== false,
    scanlines: tw.scanlines !== false,
  };
  return (
    <div style={{ position: 'absolute', inset: 0, background: '#000' }}>
      <TweakCtx.Provider value={tweaks}>
        <SceneStage width={SIZE} height={SIZE} scenes={window.OM_SCENES}
                    playback={window.OM_PLAYBACK} bg="#000000">
          {{ Approach, Cut, Eject }}
        </SceneStage>
      </TweakCtx.Provider>
      <TweaksPanel>
        <TweakSection label="Machine" />
        <TweakColor label="Accent" value={tweaks.accent}
                    options={[C.orange, C.cyan, C.yellow, '#3DDC84']}
                    onChange={(v) => setTweak('accent', v)} />
        <TweakSlider label="Chip spray" value={tweaks.chips} min={0} max={40}
                     onChange={(v) => setTweak('chips', v)} />
        <TweakToggle label="Spindle glow" value={tweaks.glow}
                     onChange={(v) => setTweak('glow', v)} />
        <TweakSection label="Screen" />
        <TweakToggle label="Scanlines" value={tweaks.scanlines}
                     onChange={(v) => setTweak('scanlines', v)} />
        <TweakToggle label="Motion editor" value={tw.motionEditor !== false}
                     onChange={(v) => setTweak('motionEditor', v)} />
      </TweaksPanel>
    </div>
  );
}

window.CncRoot = CncRoot;
