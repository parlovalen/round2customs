/* @ds-bundle: {"format":3,"namespace":"Round2CustomsDesignSystem_019deb","components":[],"sourceHashes":{"ui_kits/website/components/Footer.jsx":"407e36125ce6","ui_kits/website/components/Hero.jsx":"ac17884aa198","ui_kits/website/components/Intro.jsx":"fca495adb628","ui_kits/website/components/Nav.jsx":"87abefaf73f6","ui_kits/website/components/OriginStory.jsx":"ee6604423867","ui_kits/website/components/ProjectGrid.jsx":"83e73e96a955","ui_kits/website/components/QuestForm.jsx":"9dd082dba3d3","ui_kits/website/components/V2.jsx":"9d568cc34cca"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.Round2CustomsDesignSystem_019deb = window.Round2CustomsDesignSystem_019deb || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// ui_kits/website/components/Footer.jsx
try { (() => {
/* @jsx React.createElement */
function Footer() {
  return /*#__PURE__*/React.createElement("footer", {
    style: footStyles.wrap
  }, /*#__PURE__*/React.createElement("div", {
    style: footStyles.top
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/r2c-logo.svg",
    style: {
      height: 28
    },
    alt: "R2C"
  }), /*#__PURE__*/React.createElement("div", {
    style: footStyles.cols
  }, /*#__PURE__*/React.createElement(Col, {
    title: "STUDIO"
  }, /*#__PURE__*/React.createElement("div", null, "Lake Barrington, IL"), /*#__PURE__*/React.createElement("div", {
    style: {
      color: '#D65E38'
    }
  }, "round2customs.com")), /*#__PURE__*/React.createElement(Col, {
    title: "CONTACT"
  }, /*#__PURE__*/React.createElement("div", null, "alen@round2customs.com"), /*#__PURE__*/React.createElement("div", null, "224.522.0875")), /*#__PURE__*/React.createElement(Col, {
    title: "FOLLOW"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      color: '#59A9CC'
    }
  }, "@round2customs"))), /*#__PURE__*/React.createElement("div", {
    style: footStyles.socials
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      ...footStyles.socIcon,
      color: '#59A9CC'
    }
  }, "\u25C9"), /*#__PURE__*/React.createElement("span", {
    style: {
      ...footStyles.socIcon,
      color: '#E7BE44'
    }
  }, "\u261E"), /*#__PURE__*/React.createElement("span", {
    style: {
      ...footStyles.socIcon,
      color: '#D65E38'
    }
  }, "\u2709"))), /*#__PURE__*/React.createElement("div", {
    style: footStyles.fine
  }, "\xA9 2026 ROUND 2 CUSTOMS \xB7 HANDCRAFTED IN ILLINOIS"));
}
function Col({
  title,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'Onest', sans-serif",
      fontSize: 11,
      letterSpacing: '.18em',
      color: '#8A8A92',
      fontWeight: 500,
      textTransform: 'uppercase'
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      color: '#C9C9CE',
      fontSize: 13,
      fontFamily: "'Onest', sans-serif",
      display: 'flex',
      flexDirection: 'column',
      gap: 2
    }
  }, children));
}
const footStyles = {
  wrap: {
    background: '#0A0A0B',
    borderTop: '1px solid #1A1A1D',
    padding: '40px 80px 32px'
  },
  top: {
    display: 'grid',
    gridTemplateColumns: 'auto 1fr auto',
    gap: 48,
    alignItems: 'flex-start'
  },
  cols: {
    display: 'flex',
    gap: 56
  },
  socials: {
    display: 'flex',
    gap: 16,
    alignItems: 'center'
  },
  socIcon: {
    fontSize: 22,
    fontFamily: "'Press Start 2P', monospace",
    cursor: 'pointer'
  },
  fine: {
    marginTop: 32,
    color: '#5A5A62',
    fontSize: 11,
    letterSpacing: '.18em',
    fontFamily: "'Onest', sans-serif",
    textTransform: 'uppercase',
    fontWeight: 500
  }
};
window.Footer = Footer;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/components/Footer.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/components/Hero.jsx
try { (() => {
/* @jsx React.createElement */
function Hero() {
  return /*#__PURE__*/React.createElement("section", {
    style: heroStyles.wrap
  }, /*#__PURE__*/React.createElement("div", {
    style: heroStyles.smokeL
  }), /*#__PURE__*/React.createElement("div", {
    style: heroStyles.smokeR
  }), /*#__PURE__*/React.createElement("div", {
    style: heroStyles.center
  }, /*#__PURE__*/React.createElement("div", {
    style: heroStyles.eyebrow
  }, "INSERT COIN"), /*#__PURE__*/React.createElement("h1", {
    style: heroStyles.title
  }, "PRESS ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: '#D65E38'
    }
  }, "START")), /*#__PURE__*/React.createElement("p", {
    style: heroStyles.sub
  }, "Handcrafted, premium arcade machines tailored to your style."), /*#__PURE__*/React.createElement("button", {
    style: heroStyles.cta
  }, "START YOUR QUEST \u2192")));
}
const heroStyles = {
  wrap: {
    position: 'relative',
    overflow: 'hidden',
    padding: '120px 24px 140px',
    background: '#000'
  },
  smokeL: {
    position: 'absolute',
    left: -120,
    top: 60,
    width: 600,
    height: 520,
    background: 'radial-gradient(circle, rgba(214,51,132,.4), transparent 65%)',
    filter: 'blur(70px)',
    pointerEvents: 'none'
  },
  smokeR: {
    position: 'absolute',
    right: -120,
    top: 60,
    width: 600,
    height: 520,
    background: 'radial-gradient(circle, rgba(89,169,204,.45), transparent 65%)',
    filter: 'blur(70px)',
    pointerEvents: 'none'
  },
  center: {
    position: 'relative',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    gap: 18,
    textAlign: 'center'
  },
  eyebrow: {
    fontFamily: "'Onest', sans-serif",
    fontSize: 11,
    letterSpacing: '.32em',
    color: '#D65E38',
    fontWeight: 500,
    textTransform: 'uppercase'
  },
  title: {
    fontFamily: "'Michroma', sans-serif",
    fontSize: 80,
    letterSpacing: '.06em',
    margin: 0,
    color: '#fff',
    lineHeight: 1
  },
  sub: {
    color: '#C9C9CE',
    fontSize: 16,
    maxWidth: 520,
    lineHeight: 1.6,
    margin: 0,
    fontFamily: "'Onest', sans-serif"
  },
  cta: {
    marginTop: 12,
    background: '#D65E38',
    color: '#fff',
    border: 0,
    borderRadius: 0,
    padding: '20px 32px',
    fontFamily: "'Onest', sans-serif",
    textTransform: 'uppercase',
    letterSpacing: '.18em',
    fontSize: 12,
    fontWeight: 500,
    cursor: 'pointer',
    boxShadow: '0 0 24px rgba(214,94,56,.45)'
  }
};
window.Hero = Hero;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/components/Hero.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/components/Intro.jsx
try { (() => {
/* @jsx React.createElement */
function RainbowDivider() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 4,
      padding: '60px 0'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: 4,
      background: '#D65E38',
      boxShadow: '0 0 12px rgba(214,94,56,.55)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 4,
      background: '#E7BE44',
      boxShadow: '0 0 12px rgba(231,190,68,.5)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 4,
      background: '#59A9CC',
      boxShadow: '0 0 12px rgba(89,169,204,.5)'
    }
  }));
}
function IntroBlock() {
  return /*#__PURE__*/React.createElement("section", {
    style: introStyles.wrap
  }, /*#__PURE__*/React.createElement("div", {
    style: introStyles.eyebrow
  }, "MISSION"), /*#__PURE__*/React.createElement("p", {
    style: introStyles.body
  }, "At Round 2 Customs, we fuse timeless nostalgia with modern performance to deliver handcrafted, premium arcade machines tailored to your style."));
}
const introStyles = {
  wrap: {
    textAlign: 'center',
    padding: '60px 24px 0',
    maxWidth: 760,
    margin: '0 auto'
  },
  eyebrow: {
    fontFamily: "'Onest', sans-serif",
    fontSize: 11,
    letterSpacing: '.32em',
    color: '#D65E38',
    marginBottom: 16,
    fontWeight: 500,
    textTransform: 'uppercase'
  },
  body: {
    color: '#C9C9CE',
    fontSize: 17,
    lineHeight: 1.6,
    fontFamily: "'Onest', sans-serif"
  }
};
window.RainbowDivider = RainbowDivider;
window.IntroBlock = IntroBlock;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/components/Intro.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/components/Nav.jsx
try { (() => {
/* @jsx React.createElement */
function Nav() {
  return /*#__PURE__*/React.createElement("nav", {
    style: navStyles.bar
  }, /*#__PURE__*/React.createElement("div", {
    style: navStyles.group
  }, /*#__PURE__*/React.createElement("a", {
    style: navStyles.link
  }, "HOME"), /*#__PURE__*/React.createElement("a", {
    style: navStyles.link
  }, "BUILDS"), /*#__PURE__*/React.createElement("a", {
    style: navStyles.link
  }, "ABOUT")), /*#__PURE__*/React.createElement("img", {
    src: "../../assets/r2c-logo.svg",
    style: {
      height: 26
    },
    alt: "R2C"
  }), /*#__PURE__*/React.createElement("div", {
    style: navStyles.group
  }, /*#__PURE__*/React.createElement("a", {
    style: navStyles.link
  }, "PROCESS"), /*#__PURE__*/React.createElement("a", {
    style: navStyles.link
  }, "CONTACT"), /*#__PURE__*/React.createElement("a", {
    style: {
      ...navStyles.link,
      color: '#D65E38'
    }
  }, "QUOTE")));
}
const navStyles = {
  bar: {
    position: 'sticky',
    top: 0,
    zIndex: 30,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: '18px 48px',
    background: 'rgba(0,0,0,.75)',
    backdropFilter: 'blur(12px)',
    borderBottom: '1px solid #1A1A1D'
  },
  group: {
    display: 'flex',
    gap: 28,
    alignItems: 'center'
  },
  link: {
    color: '#fff',
    fontFamily: "'Onest', sans-serif",
    textTransform: 'uppercase',
    letterSpacing: '.16em',
    fontSize: 12,
    fontWeight: 500,
    cursor: 'pointer'
  }
};
window.Nav = Nav;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/components/Nav.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/components/OriginStory.jsx
try { (() => {
/* @jsx React.createElement */
function OriginStory() {
  return /*#__PURE__*/React.createElement("section", {
    style: originStyles.wrap
  }, /*#__PURE__*/React.createElement("div", {
    style: originStyles.text
  }, /*#__PURE__*/React.createElement("div", {
    style: originStyles.eyebrow
  }, "PRESS START"), /*#__PURE__*/React.createElement("h2", {
    style: originStyles.title
  }, "THE ORIGIN STORY"), /*#__PURE__*/React.createElement("p", {
    style: originStyles.body
  }, "Founder Alen Parlov spent his childhood in arcades and his career between a woodshop and an electrical bench. Round 2 Customs is what happens when those two obsessions meet \u2014 bespoke machines that look stunning, perform flawlessly, and stand the test of time."), /*#__PURE__*/React.createElement("p", {
    style: originStyles.body
  }, "We don't ship flat-pack. We don't cut corners. Every cabinet is built one at a time, by hand, in Lake Barrington, Illinois."), /*#__PURE__*/React.createElement("a", {
    style: originStyles.link
  }, "READ THE FULL STORY \u2192")), /*#__PURE__*/React.createElement("div", {
    style: originStyles.illoWrap
  }, /*#__PURE__*/React.createElement(CabinetIllustration, null)));
}
function CabinetIllustration() {
  return /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 220 320",
    width: "280",
    height: "auto"
  }, /*#__PURE__*/React.createElement("g", {
    fill: "none",
    stroke: "#D65E38",
    strokeWidth: "1.5"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "40",
    y: "20",
    width: "140",
    height: "40"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "30",
    y: "60",
    width: "160",
    height: "120"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "50",
    y: "80",
    width: "120",
    height: "80",
    fill: "#0a0a0b",
    stroke: "#D65E38"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "30",
    y: "180",
    width: "160",
    height: "40"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "80",
    cy: "200",
    r: "6"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "110",
    cy: "200",
    r: "4"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "130",
    cy: "200",
    r: "4"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "150",
    cy: "200",
    r: "4"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "40",
    y: "220",
    width: "140",
    height: "80"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "40",
    y1: "240",
    x2: "180",
    y2: "240"
  })));
}
const originStyles = {
  wrap: {
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gap: 48,
    padding: '80px 80px',
    maxWidth: 1200,
    margin: '0 auto',
    alignItems: 'center'
  },
  text: {
    display: 'flex',
    flexDirection: 'column',
    gap: 14
  },
  eyebrow: {
    fontFamily: "'Onest', sans-serif",
    fontSize: 11,
    letterSpacing: '.32em',
    color: '#D65E38',
    fontWeight: 500,
    textTransform: 'uppercase'
  },
  title: {
    fontFamily: "'Michroma', sans-serif",
    fontSize: 32,
    letterSpacing: '.14em',
    color: '#fff',
    margin: '4px 0 8px'
  },
  body: {
    color: '#C9C9CE',
    fontSize: 14,
    lineHeight: 1.7,
    fontFamily: "'Onest', sans-serif",
    margin: 0
  },
  link: {
    color: '#D65E38',
    fontFamily: "'Onest', sans-serif",
    fontSize: 12,
    letterSpacing: '.18em',
    marginTop: 12,
    cursor: 'pointer',
    fontWeight: 500,
    textTransform: 'uppercase'
  },
  illoWrap: {
    display: 'flex',
    justifyContent: 'center'
  }
};
window.OriginStory = OriginStory;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/components/OriginStory.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/components/ProjectGrid.jsx
try { (() => {
/* @jsx React.createElement */
function ProjectGrid() {
  const projects = [{
    name: 'NEON HEIST',
    tag: 'Spider-Man · 2P',
    g1: '#D63384',
    g2: '#D65E38'
  }, {
    name: 'COIN HOARD',
    tag: 'Pac-Man · 1P',
    g1: '#E7BE44',
    g2: '#000'
  }, {
    name: 'TILT ROYALE',
    tag: 'Pinball · BAR EDITION',
    g1: '#59A9CC',
    g2: '#D63384'
  }, {
    name: 'BAT SIGNAL',
    tag: 'Batman · 2P',
    g1: '#D65E38',
    g2: '#59A9CC'
  }];
  return /*#__PURE__*/React.createElement("section", {
    style: pgStyles.wrap
  }, /*#__PURE__*/React.createElement("div", {
    style: pgStyles.head
  }, /*#__PURE__*/React.createElement("div", {
    style: pgStyles.eyebrow
  }, "HALL OF FAME"), /*#__PURE__*/React.createElement("h2", {
    style: pgStyles.title
  }, "EXAMPLE PROJECTS")), /*#__PURE__*/React.createElement("div", {
    style: pgStyles.grid
  }, projects.map(p => /*#__PURE__*/React.createElement("div", {
    key: p.name,
    style: pgStyles.card
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...pgStyles.thumb,
      background: `linear-gradient(160deg, ${p.g1}, ${p.g2})`
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: pgStyles.thumbInner
  })), /*#__PURE__*/React.createElement("div", {
    style: pgStyles.cardBody
  }, /*#__PURE__*/React.createElement("div", {
    style: pgStyles.cardName
  }, p.name), /*#__PURE__*/React.createElement("div", {
    style: pgStyles.cardTag
  }, p.tag))))));
}
const pgStyles = {
  wrap: {
    padding: '40px 80px 80px',
    maxWidth: 1280,
    margin: '0 auto'
  },
  head: {
    textAlign: 'center',
    marginBottom: 36
  },
  eyebrow: {
    fontFamily: "'Onest', sans-serif",
    fontSize: 11,
    letterSpacing: '.32em',
    color: '#D65E38',
    marginBottom: 12,
    fontWeight: 500,
    textTransform: 'uppercase'
  },
  title: {
    fontFamily: "'Michroma', sans-serif",
    fontSize: 28,
    letterSpacing: '.16em',
    color: '#fff',
    margin: 0
  },
  grid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(4, 1fr)',
    gap: 16
  },
  card: {
    background: 'transparent',
    border: '1px solid #2A2A2E',
    borderRadius: 0,
    overflow: 'hidden',
    cursor: 'pointer',
    transition: 'all .2s'
  },
  thumb: {
    aspectRatio: '4/5',
    position: 'relative'
  },
  thumbInner: {
    position: 'absolute',
    inset: '20% 15%',
    background: 'rgba(0,0,0,.45)',
    border: '2px solid rgba(255,255,255,.08)'
  },
  cardBody: {
    padding: '16px 18px',
    display: 'flex',
    flexDirection: 'column',
    gap: 6
  },
  cardName: {
    fontFamily: "'Michroma', sans-serif",
    fontSize: 11,
    letterSpacing: '.18em',
    color: '#fff'
  },
  cardTag: {
    fontSize: 11,
    color: '#8A8A92',
    fontFamily: "'Onest', sans-serif"
  }
};
window.ProjectGrid = ProjectGrid;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/components/ProjectGrid.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/components/QuestForm.jsx
try { (() => {
/* @jsx React.createElement */
const {
  useState: useStateQ
} = React;
function QuestForm() {
  const [name, setName] = useStateQ('');
  const [email, setEmail] = useStateQ('');
  const [brief, setBrief] = useStateQ('');
  const [sent, setSent] = useStateQ(false);
  return /*#__PURE__*/React.createElement("section", {
    style: qfStyles.wrap
  }, /*#__PURE__*/React.createElement("div", {
    style: qfStyles.left
  }, /*#__PURE__*/React.createElement("div", {
    style: qfStyles.eyebrow
  }, "READY PLAYER 1?"), /*#__PURE__*/React.createElement("h2", {
    style: qfStyles.title
  }, "START YOUR", /*#__PURE__*/React.createElement("br", null), "QUEST"), /*#__PURE__*/React.createElement("p", {
    style: qfStyles.body
  }, "Tell us about the cabinet you've been dreaming up. We'll come back with a quote, a timeline, and a few questions you didn't know to ask.")), /*#__PURE__*/React.createElement("div", {
    style: qfStyles.right
  }, sent ? /*#__PURE__*/React.createElement("div", {
    style: qfStyles.thanks
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'Press Start 2P'",
      color: '#59CC98',
      fontSize: 14,
      marginBottom: 16
    }
  }, "1UP"), /*#__PURE__*/React.createElement("div", {
    style: qfStyles.title
  }, "QUEST ACCEPTED"), /*#__PURE__*/React.createElement("p", {
    style: qfStyles.body
  }, "We'll reply within 2 business days.")) : /*#__PURE__*/React.createElement("form", {
    style: qfStyles.form,
    onSubmit: e => {
      e.preventDefault();
      setSent(true);
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: qfStyles.row2
  }, /*#__PURE__*/React.createElement(Field, {
    label: "PLAYER NAME",
    value: name,
    onChange: setName
  }), /*#__PURE__*/React.createElement(Field, {
    label: "LAST NAME"
  })), /*#__PURE__*/React.createElement(Field, {
    label: "EMAIL ADDRESS",
    value: email,
    onChange: setEmail
  }), /*#__PURE__*/React.createElement(Field, {
    label: "PROJECT BRIEF",
    multiline: true,
    value: brief,
    onChange: setBrief
  }), /*#__PURE__*/React.createElement("button", {
    type: "submit",
    style: qfStyles.cta
  }, "SEND \u2192"))));
}
function Field({
  label,
  value,
  onChange,
  multiline
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: qfStyles.field
  }, /*#__PURE__*/React.createElement("span", {
    style: qfStyles.label
  }, label), multiline ? /*#__PURE__*/React.createElement("textarea", {
    rows: 3,
    style: {
      ...qfStyles.input,
      resize: 'vertical'
    },
    value: value || '',
    onChange: e => onChange?.(e.target.value)
  }) : /*#__PURE__*/React.createElement("input", {
    style: qfStyles.input,
    value: value || '',
    onChange: e => onChange?.(e.target.value)
  }));
}
const qfStyles = {
  wrap: {
    display: 'grid',
    gridTemplateColumns: '1fr 1.4fr',
    gap: 64,
    padding: '80px 80px',
    maxWidth: 1200,
    margin: '0 auto',
    alignItems: 'flex-start'
  },
  left: {
    display: 'flex',
    flexDirection: 'column',
    gap: 14
  },
  right: {
    width: '100%'
  },
  eyebrow: {
    fontFamily: "'Onest', sans-serif",
    fontSize: 11,
    letterSpacing: '.32em',
    color: '#D65E38',
    fontWeight: 500,
    textTransform: 'uppercase'
  },
  title: {
    fontFamily: "'Michroma', sans-serif",
    fontSize: 32,
    letterSpacing: '.12em',
    color: '#fff',
    margin: '4px 0 8px',
    lineHeight: 1.1
  },
  body: {
    color: '#C9C9CE',
    fontSize: 14,
    lineHeight: 1.7,
    fontFamily: "'Onest', sans-serif",
    margin: 0
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    gap: 14
  },
  row2: {
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gap: 12
  },
  field: {
    display: 'flex',
    flexDirection: 'column',
    gap: 6
  },
  label: {
    fontFamily: "'Onest', sans-serif",
    fontSize: 11,
    letterSpacing: '.18em',
    color: '#8A8A92',
    fontWeight: 500,
    textTransform: 'uppercase'
  },
  input: {
    background: 'rgba(255,255,255,.04)',
    border: '1px solid #2A2A2E',
    borderRadius: 0,
    color: '#fff',
    padding: '14px 16px',
    fontFamily: "'Onest', sans-serif",
    fontSize: 14,
    outline: 0
  },
  cta: {
    alignSelf: 'flex-start',
    marginTop: 8,
    background: '#D65E38',
    color: '#fff',
    border: 0,
    borderRadius: 0,
    padding: '20px 32px',
    fontFamily: "'Onest', sans-serif",
    letterSpacing: '.18em',
    fontSize: 12,
    fontWeight: 500,
    cursor: 'pointer',
    boxShadow: '0 0 24px rgba(214,94,56,.45)',
    textTransform: 'uppercase'
  },
  thanks: {
    padding: '32px 0'
  }
};
window.QuestForm = QuestForm;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/components/QuestForm.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/components/V2.jsx
try { (() => {
/* @jsx React.createElement */
function NavV2() {
  return /*#__PURE__*/React.createElement("nav", {
    style: navV2.bar
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/r2c-logo.svg",
    style: {
      height: 24
    },
    alt: "R2C"
  }), /*#__PURE__*/React.createElement("div", {
    style: navV2.links
  }, /*#__PURE__*/React.createElement("a", {
    style: navV2.link
  }, "WORK"), /*#__PURE__*/React.createElement("a", {
    style: navV2.link
  }, "PROCESS"), /*#__PURE__*/React.createElement("a", {
    style: navV2.link
  }, "STUDIO"), /*#__PURE__*/React.createElement("a", {
    style: navV2.link
  }, "JOURNAL")), /*#__PURE__*/React.createElement("button", {
    style: navV2.cta
  }, "START YOUR QUEST"));
}
const navV2 = {
  bar: {
    position: 'sticky',
    top: 0,
    zIndex: 30,
    display: 'grid',
    gridTemplateColumns: 'auto 1fr auto',
    alignItems: 'center',
    gap: 48,
    padding: '20px 56px',
    background: 'rgba(0,0,0,.8)',
    backdropFilter: 'blur(12px)',
    borderBottom: '1px solid #1A1A1D'
  },
  links: {
    display: 'flex',
    gap: 36,
    justifyContent: 'center'
  },
  link: {
    color: '#fff',
    fontFamily: "'Onest',sans-serif",
    textTransform: 'uppercase',
    letterSpacing: '.16em',
    fontSize: 12,
    fontWeight: 500,
    cursor: 'pointer'
  },
  cta: {
    background: '#D65E38',
    color: '#fff',
    border: 0,
    borderRadius: 0,
    padding: '14px 22px',
    fontFamily: "'Onest',sans-serif",
    fontWeight: 500,
    letterSpacing: '.18em',
    fontSize: 11,
    textTransform: 'uppercase',
    cursor: 'pointer'
  }
};
function HeroV2() {
  return /*#__PURE__*/React.createElement("section", {
    style: heroV2.wrap
  }, /*#__PURE__*/React.createElement("div", {
    style: heroV2.left
  }, /*#__PURE__*/React.createElement("div", {
    style: heroV2.eyebrow
  }, "EST. 2019 \xB7 LAKE BARRINGTON, IL"), /*#__PURE__*/React.createElement("h1", {
    style: heroV2.h1
  }, "BUILT BY HAND.", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("span", {
    style: {
      color: '#D65E38'
    }
  }, "PLAYED FOR LIFE.")), /*#__PURE__*/React.createElement("p", {
    style: heroV2.lede
  }, "Round 2 Customs designs and handcrafts premium arcade machines \u2014 bespoke builds for collectors, game rooms, and the kinds of places where a flat-pack cabinet just won't do."), /*#__PURE__*/React.createElement("div", {
    style: heroV2.row
  }, /*#__PURE__*/React.createElement("button", {
    style: heroV2.cta
  }, "START YOUR QUEST \u2192"), /*#__PURE__*/React.createElement("a", {
    style: heroV2.ghost
  }, "SEE THE BUILDS"))), /*#__PURE__*/React.createElement("div", {
    style: heroV2.right
  }, /*#__PURE__*/React.createElement("div", {
    style: heroV2.smokeP
  }), /*#__PURE__*/React.createElement("div", {
    style: heroV2.smokeC
  }), /*#__PURE__*/React.createElement("div", {
    style: heroV2.cabinet
  }, /*#__PURE__*/React.createElement("div", {
    style: heroV2.marquee
  }, "ROUND 2 CUSTOMS"), /*#__PURE__*/React.createElement("div", {
    style: heroV2.screen
  }, /*#__PURE__*/React.createElement("div", {
    style: heroV2.screenInner
  }, /*#__PURE__*/React.createElement("div", {
    style: heroV2.flicker
  }, "READY", /*#__PURE__*/React.createElement("br", null), "PLAYER 1"))), /*#__PURE__*/React.createElement("div", {
    style: heroV2.controls
  }, /*#__PURE__*/React.createElement("div", {
    style: heroV2.stick
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: heroV2.btn
  }), /*#__PURE__*/React.createElement("div", {
    style: heroV2.btn
  }), /*#__PURE__*/React.createElement("div", {
    style: heroV2.btn
  })), /*#__PURE__*/React.createElement("div", {
    style: heroV2.stick
  })), /*#__PURE__*/React.createElement("div", {
    style: heroV2.base
  }))));
}
const heroV2 = {
  wrap: {
    display: 'grid',
    gridTemplateColumns: '1.05fr 1fr',
    gap: 64,
    padding: '80px 80px 100px',
    alignItems: 'center',
    position: 'relative',
    overflow: 'hidden'
  },
  left: {
    display: 'flex',
    flexDirection: 'column',
    gap: 24
  },
  eyebrow: {
    fontFamily: "'Onest',sans-serif",
    letterSpacing: '.32em',
    fontSize: 11,
    color: '#D65E38',
    fontWeight: 500,
    textTransform: 'uppercase'
  },
  h1: {
    fontFamily: "'Michroma',sans-serif",
    fontSize: 64,
    lineHeight: 1.05,
    letterSpacing: '.04em',
    margin: 0,
    color: '#fff'
  },
  lede: {
    color: '#C9C9CE',
    fontSize: 17,
    lineHeight: 1.6,
    fontFamily: "'Onest',sans-serif",
    maxWidth: 520,
    margin: 0
  },
  row: {
    display: 'flex',
    gap: 18,
    alignItems: 'center',
    marginTop: 8
  },
  cta: {
    background: '#D65E38',
    color: '#fff',
    border: 0,
    borderRadius: 0,
    padding: '20px 28px',
    fontFamily: "'Onest',sans-serif",
    fontWeight: 500,
    letterSpacing: '.18em',
    fontSize: 12,
    textTransform: 'uppercase',
    cursor: 'pointer',
    boxShadow: '0 0 24px rgba(214,94,56,.45)'
  },
  ghost: {
    color: '#fff',
    fontFamily: "'Onest',sans-serif",
    fontSize: 12,
    fontWeight: 500,
    letterSpacing: '.18em',
    textTransform: 'uppercase',
    cursor: 'pointer',
    borderBottom: '1px solid #2A2A2E',
    paddingBottom: 6
  },
  right: {
    position: 'relative',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    minHeight: 480
  },
  smokeP: {
    position: 'absolute',
    left: -40,
    top: 40,
    width: 380,
    height: 380,
    background: 'radial-gradient(circle, rgba(214,51,132,.5), transparent 65%)',
    filter: 'blur(60px)'
  },
  smokeC: {
    position: 'absolute',
    right: -40,
    top: 40,
    width: 380,
    height: 380,
    background: 'radial-gradient(circle, rgba(89,169,204,.5), transparent 65%)',
    filter: 'blur(60px)'
  },
  cabinet: {
    position: 'relative',
    width: 300,
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center'
  },
  marquee: {
    width: 300,
    height: 46,
    background: '#0A0A0B',
    border: '4px solid #fff',
    borderBottom: 0,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontFamily: "'Michroma',sans-serif",
    fontSize: 10,
    letterSpacing: '.2em'
  },
  screen: {
    width: 300,
    height: 200,
    background: '#000',
    border: '5px solid #fff',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    boxShadow: 'inset 0 0 50px rgba(214,94,56,.25)'
  },
  screenInner: {
    textAlign: 'center'
  },
  flicker: {
    fontFamily: "'Press Start 2P',monospace",
    color: '#E7BE44',
    fontSize: 18,
    lineHeight: 1.4,
    textShadow: '0 0 18px #D65E38'
  },
  controls: {
    width: 300,
    height: 54,
    background: '#1c1c1e',
    borderLeft: '5px solid #fff',
    borderRight: '5px solid #fff',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-around'
  },
  stick: {
    width: 20,
    height: 30,
    borderRadius: 20,
    background: '#D65E38',
    boxShadow: '0 0 0 2px #000, 0 4px 0 #7a2d18'
  },
  btn: {
    width: 14,
    height: 14,
    borderRadius: '50%',
    background: '#fff'
  },
  base: {
    width: 300,
    height: 160,
    background: 'linear-gradient(180deg,#5a3d28,#3a2618)',
    border: '5px solid #fff',
    borderTop: 0
  }
};
function StripeBar() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 3,
      padding: '4px 0'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: 3,
      background: '#D65E38'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 3,
      background: '#E7BE44'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 3,
      background: '#59A9CC'
    }
  }));
}
function StatStrip() {
  const stats = [['07+', 'YEARS BUILDING'], ['1 OF 1', 'EVERY CABINET'], ['100%', 'HAND-FINISHED'], ['IL · USA', 'ASSEMBLED']];
  return /*#__PURE__*/React.createElement("section", {
    style: statStyle.wrap
  }, stats.map(([n, l]) => /*#__PURE__*/React.createElement("div", {
    key: l,
    style: statStyle.cell
  }, /*#__PURE__*/React.createElement("div", {
    style: statStyle.n
  }, n), /*#__PURE__*/React.createElement("div", {
    style: statStyle.l
  }, l))));
}
const statStyle = {
  wrap: {
    display: 'grid',
    gridTemplateColumns: 'repeat(4,1fr)',
    borderTop: '1px solid #1F1F22',
    borderBottom: '1px solid #1F1F22'
  },
  cell: {
    padding: '32px 24px',
    borderRight: '1px solid #1F1F22',
    display: 'flex',
    flexDirection: 'column',
    gap: 8
  },
  n: {
    fontFamily: "'Michroma',sans-serif",
    fontSize: 28,
    color: '#fff',
    letterSpacing: '.04em'
  },
  l: {
    fontFamily: "'Onest',sans-serif",
    fontSize: 11,
    letterSpacing: '.22em',
    color: '#8A8A92',
    fontWeight: 500,
    textTransform: 'uppercase'
  }
};
function Manifesto() {
  return /*#__PURE__*/React.createElement("section", {
    style: manStyle.wrap
  }, /*#__PURE__*/React.createElement("div", {
    style: manStyle.eyebrow
  }, "WHAT WE BELIEVE"), /*#__PURE__*/React.createElement("p", {
    style: manStyle.body
  }, "Most arcade cabinets are ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: '#fff'
    }
  }, "flimsy, mass-produced, disposable"), ". Ours aren't. Every Round 2 cabinet is engineered from the bench up \u2014 the same hands wire the boards and shape the cabinet. No flat packs. No shortcuts. Built to look stunning, perform flawlessly, and outlive the trend cycle."), /*#__PURE__*/React.createElement("div", {
    style: manStyle.sig
  }, "\u2014 ALEN PARLOV, FOUNDER"));
}
const manStyle = {
  wrap: {
    padding: '100px 80px',
    maxWidth: 980,
    margin: '0 auto',
    textAlign: 'center',
    display: 'flex',
    flexDirection: 'column',
    gap: 24,
    alignItems: 'center'
  },
  eyebrow: {
    fontFamily: "'Onest',sans-serif",
    letterSpacing: '.32em',
    fontSize: 11,
    color: '#D65E38',
    fontWeight: 500,
    textTransform: 'uppercase'
  },
  body: {
    fontFamily: "'Onest',sans-serif",
    fontSize: 24,
    lineHeight: 1.5,
    color: '#8A8A92',
    margin: 0,
    maxWidth: 820
  },
  sig: {
    fontFamily: "'Onest',sans-serif",
    letterSpacing: '.22em',
    fontSize: 11,
    color: '#fff',
    fontWeight: 500,
    marginTop: 8
  }
};
function ProcessV2() {
  const steps = [['01', 'BRIEF', 'You tell us about the build — theme, players, footprint, the games that matter.'], ['02', 'DESIGN', 'Renders, finishes, hardware specs. We iterate until you can already see it in the room.'], ['03', 'BUILD', 'Cabinet milled and finished in the woodshop. Boards wired and tuned at the bench.'], ['04', 'DELIVER', 'White-glove install. Tutorial included. Then you press start.']];
  return /*#__PURE__*/React.createElement("section", {
    style: pv2.wrap
  }, /*#__PURE__*/React.createElement("div", {
    style: pv2.head
  }, /*#__PURE__*/React.createElement("div", {
    style: pv2.eyebrow
  }, "SELECT YOUR CHARACTER"), /*#__PURE__*/React.createElement("h2", {
    style: pv2.title
  }, "HOW A QUEST GETS BUILT")), /*#__PURE__*/React.createElement("div", {
    style: pv2.grid
  }, steps.map(([n, t, b]) => /*#__PURE__*/React.createElement("div", {
    key: n,
    style: pv2.card
  }, /*#__PURE__*/React.createElement("div", {
    style: pv2.num
  }, n), /*#__PURE__*/React.createElement("div", {
    style: pv2.t
  }, t), /*#__PURE__*/React.createElement("div", {
    style: pv2.b
  }, b)))));
}
const pv2 = {
  wrap: {
    padding: '80px 80px',
    maxWidth: 1280,
    margin: '0 auto'
  },
  head: {
    display: 'flex',
    flexDirection: 'column',
    gap: 12,
    marginBottom: 40
  },
  eyebrow: {
    fontFamily: "'Onest',sans-serif",
    letterSpacing: '.32em',
    fontSize: 11,
    color: '#D65E38',
    fontWeight: 500,
    textTransform: 'uppercase'
  },
  title: {
    fontFamily: "'Michroma',sans-serif",
    fontSize: 32,
    letterSpacing: '.12em',
    color: '#fff',
    margin: 0
  },
  grid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(4,1fr)',
    gap: 0,
    borderTop: '1px solid #1F1F22'
  },
  card: {
    padding: '32px 28px 36px',
    borderRight: '1px solid #1F1F22',
    borderBottom: '1px solid #1F1F22',
    display: 'flex',
    flexDirection: 'column',
    gap: 14
  },
  num: {
    fontFamily: "'Michroma',sans-serif",
    color: '#D65E38',
    fontSize: 14,
    letterSpacing: '.2em'
  },
  t: {
    fontFamily: "'Michroma',sans-serif",
    color: '#fff',
    fontSize: 18,
    letterSpacing: '.16em'
  },
  b: {
    fontFamily: "'Onest',sans-serif",
    color: '#C9C9CE',
    fontSize: 14,
    lineHeight: 1.6
  }
};
function GalleryStrip() {
  const tiles = [{
    name: 'NEON HEIST',
    tag: 'Spider-Man · 2P',
    g1: '#D63384',
    g2: '#D65E38'
  }, {
    name: 'COIN HOARD',
    tag: 'Pac-Man · 1P',
    g1: '#E7BE44',
    g2: '#0A0A0B'
  }, {
    name: 'TILT ROYALE',
    tag: 'Pinball · BAR EDITION',
    g1: '#59A9CC',
    g2: '#D63384'
  }, {
    name: 'BAT SIGNAL',
    tag: 'Batman · 2P',
    g1: '#D65E38',
    g2: '#59A9CC'
  }];
  return /*#__PURE__*/React.createElement("section", {
    style: gs.wrap
  }, /*#__PURE__*/React.createElement("div", {
    style: gs.head
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: gs.eyebrow
  }, "HALL OF FAME"), /*#__PURE__*/React.createElement("h2", {
    style: gs.title
  }, "RECENT BUILDS")), /*#__PURE__*/React.createElement("a", {
    style: gs.link
  }, "SEE ALL 24 \u2192")), /*#__PURE__*/React.createElement("div", {
    style: gs.grid
  }, tiles.map(t => /*#__PURE__*/React.createElement("article", {
    key: t.name,
    style: gs.card
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...gs.thumb,
      background: `linear-gradient(160deg, ${t.g1}, ${t.g2})`
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: gs.thumbInner
  })), /*#__PURE__*/React.createElement("div", {
    style: gs.body
  }, /*#__PURE__*/React.createElement("div", {
    style: gs.name
  }, t.name), /*#__PURE__*/React.createElement("div", {
    style: gs.tag
  }, t.tag))))));
}
const gs = {
  wrap: {
    padding: '40px 80px 100px',
    maxWidth: 1280,
    margin: '0 auto'
  },
  head: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    marginBottom: 32
  },
  eyebrow: {
    fontFamily: "'Onest',sans-serif",
    letterSpacing: '.32em',
    fontSize: 11,
    color: '#D65E38',
    fontWeight: 500,
    textTransform: 'uppercase',
    marginBottom: 10
  },
  title: {
    fontFamily: "'Michroma',sans-serif",
    fontSize: 32,
    letterSpacing: '.12em',
    color: '#fff',
    margin: 0
  },
  link: {
    color: '#fff',
    fontFamily: "'Onest',sans-serif",
    fontWeight: 500,
    fontSize: 12,
    letterSpacing: '.18em',
    textTransform: 'uppercase',
    cursor: 'pointer',
    borderBottom: '1px solid #2A2A2E',
    paddingBottom: 6
  },
  grid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(4,1fr)',
    gap: 16
  },
  card: {
    display: 'flex',
    flexDirection: 'column',
    cursor: 'pointer'
  },
  thumb: {
    aspectRatio: '4/5',
    position: 'relative',
    border: '1px solid #2A2A2E'
  },
  thumbInner: {
    position: 'absolute',
    inset: '18% 14%',
    background: 'rgba(0,0,0,.45)',
    border: '2px solid rgba(255,255,255,.08)'
  },
  body: {
    padding: '14px 0 0',
    display: 'flex',
    flexDirection: 'column',
    gap: 6
  },
  name: {
    fontFamily: "'Michroma',sans-serif",
    fontSize: 12,
    letterSpacing: '.18em',
    color: '#fff'
  },
  tag: {
    fontSize: 12,
    color: '#8A8A92',
    fontFamily: "'Onest',sans-serif"
  }
};
function CTABanner() {
  return /*#__PURE__*/React.createElement("section", {
    style: cb.wrap
  }, /*#__PURE__*/React.createElement("div", {
    style: cb.eyebrow
  }, "READY PLAYER 1?"), /*#__PURE__*/React.createElement("h2", {
    style: cb.h
  }, "YOUR CABINET DOESN'T ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: '#D65E38'
    }
  }, "EXIST YET."), /*#__PURE__*/React.createElement("br", null), "LET'S FIX THAT."), /*#__PURE__*/React.createElement("button", {
    style: cb.cta
  }, "START YOUR QUEST \u2192"));
}
const cb = {
  wrap: {
    padding: '120px 80px',
    textAlign: 'center',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    gap: 24,
    borderTop: '1px solid #1F1F22',
    borderBottom: '1px solid #1F1F22'
  },
  eyebrow: {
    fontFamily: "'Onest',sans-serif",
    letterSpacing: '.32em',
    fontSize: 11,
    color: '#D65E38',
    fontWeight: 500,
    textTransform: 'uppercase'
  },
  h: {
    fontFamily: "'Michroma',sans-serif",
    fontSize: 48,
    letterSpacing: '.06em',
    color: '#fff',
    lineHeight: 1.15,
    margin: 0
  },
  cta: {
    background: '#D65E38',
    color: '#fff',
    border: 0,
    borderRadius: 0,
    padding: '22px 36px',
    fontFamily: "'Onest',sans-serif",
    fontWeight: 500,
    letterSpacing: '.18em',
    fontSize: 13,
    textTransform: 'uppercase',
    cursor: 'pointer',
    marginTop: 8,
    boxShadow: '0 0 30px rgba(214,94,56,.45)'
  }
};
function FooterV2() {
  return /*#__PURE__*/React.createElement("footer", {
    style: fv2.wrap
  }, /*#__PURE__*/React.createElement("div", {
    style: fv2.top
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 18,
      maxWidth: 340
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/r2c-logo.svg",
    style: {
      height: 30
    },
    alt: "R2C"
  }), /*#__PURE__*/React.createElement("div", {
    style: fv2.muted
  }, "Custom arcade cabinets, handcrafted in Lake Barrington, IL.")), /*#__PURE__*/React.createElement("div", {
    style: fv2.cols
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: fv2.colTitle
  }, "STUDIO"), /*#__PURE__*/React.createElement("div", {
    style: fv2.li
  }, "Lake Barrington, IL"), /*#__PURE__*/React.createElement("div", {
    style: fv2.li
  }, "By appointment only")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: fv2.colTitle
  }, "CONTACT"), /*#__PURE__*/React.createElement("div", {
    style: fv2.li
  }, "alen@round2customs.com"), /*#__PURE__*/React.createElement("div", {
    style: fv2.li
  }, "224.522.0875")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: fv2.colTitle
  }, "FOLLOW"), /*#__PURE__*/React.createElement("div", {
    style: {
      ...fv2.li,
      color: '#59A9CC'
    }
  }, "@round2customs")))), /*#__PURE__*/React.createElement("div", {
    style: fv2.bot
  }, "\xA9 2026 ROUND 2 CUSTOMS \xB7 ALL CABINETS HANDBUILT \xB7 NO FLAT PACKS"));
}
const fv2 = {
  wrap: {
    padding: '48px 80px 32px',
    borderTop: '1px solid #1A1A1D',
    background: '#000'
  },
  top: {
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gap: 48,
    alignItems: 'flex-start'
  },
  cols: {
    display: 'grid',
    gridTemplateColumns: 'repeat(3,1fr)',
    gap: 36
  },
  colTitle: {
    fontFamily: "'Onest',sans-serif",
    letterSpacing: '.22em',
    fontSize: 11,
    color: '#8A8A92',
    fontWeight: 500,
    textTransform: 'uppercase',
    marginBottom: 12
  },
  li: {
    fontFamily: "'Onest',sans-serif",
    fontSize: 13,
    color: '#C9C9CE',
    marginBottom: 4
  },
  muted: {
    fontFamily: "'Onest',sans-serif",
    fontSize: 13,
    color: '#8A8A92',
    lineHeight: 1.6
  },
  bot: {
    marginTop: 48,
    paddingTop: 24,
    borderTop: '1px solid #1A1A1D',
    fontFamily: "'Onest',sans-serif",
    fontSize: 11,
    letterSpacing: '.18em',
    color: '#5A5A62',
    fontWeight: 500,
    textTransform: 'uppercase'
  }
};
Object.assign(window, {
  NavV2,
  HeroV2,
  StripeBar,
  StatStrip,
  Manifesto,
  ProcessV2,
  GalleryStrip,
  CTABanner,
  FooterV2
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/components/V2.jsx", error: String((e && e.message) || e) }); }

})();
