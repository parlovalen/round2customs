/* 8-bit CNC gantry router — FRONT ELEVATION, pixel line-art.
   Everything is 1px pixel strokes on black: outlines, ticks, profiles. */

const PX = 12;
const G = 80;
const SIZE = G * PX;

const C = {
  bg: '#000000',
  line: '#9BA1AA',   // single stroke shade
  dim: '#9BA1AA',
  faint: '#9BA1AA',
  wood: '#E15A2B',   // workpiece stroke
  woodDim: '#E15A2B',
  orange: '#E15A2B',
  hot: '#FF7A45',
  cyan: '#2EB6E0',
  yellow: '#F5C518',
  magenta: '#D63384',
};

/* ── geometry (front view) ──────────────────────────────────────────────── */

const FLOOR = 72;
const BASE = { x: 12, y: 60, w: 56, h: 13 };
const TABLE = { x: 14, y: 56, w: 52, h: 4 };
const SLAB = { x: 24, y: 50, w: 33, h: 6 };   // top y=50, bottom y=55
const UPR = [{ x: 16, w: 4 }, { x: 61, w: 4 }];
const UPR_TOP = 22;
const BEAM = { x: 16, y: 26, w: 49, h: 5 };
const CUT_FROM = 28, CUT_TO = 52;
const KERF_Y = 53;
const SPIN_TOP = 35;
const Z_UP = 44, Z_DOWN = 51;                  // spindle bottom edge
const HOME_X = 24;
const HOME_CAM = { cx: 40.5, cy: 41, z: 1.35 };
const CUT_Z = 1;

const cutU = interpolate([0, 0.08, 0.92, 1], [0, 0.06, 0.94, 1], Easing.easeInOutCubic);
const lerp = (a, b, t) => a + (b - a) * t;
// sub-pixel quantization: thirds of a grid pixel keeps strokes crisp but
// removes the 12px-per-step judder of whole-pixel snapping
const qp = (v) => Math.round(v * 6) / 6;
const bitXAtU = (u) => qp(lerp(CUT_FROM, CUT_TO, u));

function cutCam() { return HOME_CAM; }
function lerpCam(a, b, t) {
  return { cx: lerp(a.cx, b.cx, t), cy: lerp(a.cy, b.cy, t), z: lerp(a.z, b.z, t) };
}
function viewBox(cam) {
  const z = Math.round(cam.z * 20) / 20;
  const s = G / z, half = s / 2;
  const cx = Math.min(G - half, Math.max(half, cam.cx));
  const cy = Math.min(G - half, Math.max(half, cam.cy));
  const q = (v) => Math.round(v * 2) / 2;
  return `${q(cx - half)} ${q(cy - half)} ${s} ${s}`;
}

/* ── stroke helpers ─────────────────────────────────────────────────────── */

let _k = 0;
const nk = () => 'p' + (_k++);
const HL = (x, y, w, fill, o) => React.createElement('rect', { key: nk(), x, y, width: w, height: 1, fill, opacity: o });
const VL = (x, y, h, fill, o) => React.createElement('rect', { key: nk(), x, y, width: 1, height: h, fill, opacity: o });
const PT = (x, y, fill, o) => React.createElement('rect', { key: nk(), x, y, width: 1, height: 1, fill, opacity: o });
function box(x, y, w, h, fill, o) {
  return [HL(x, y, w, fill, o), HL(x, y + h - 1, w, fill, o), VL(x, y, h, fill, o), VL(x + w - 1, y, h, fill, o)];
}
function dashH(x, y, w, fill, o, step) {
  const out = [];
  for (let i = 0; i < w; i += (step || 2)) out.push(PT(x + i, y, fill, o));
  return out;
}
function dashV(x, y, h, fill, o, step) {
  const out = [];
  for (let i = 0; i < h; i += (step || 2)) out.push(PT(x, y + i, fill, o));
  return out;
}

/* ── machine parts ──────────────────────────────────────────────────────── */

function Frame() {
  const el = [];
  // table
  el.push(...box(TABLE.x, TABLE.y, TABLE.w, TABLE.h, C.line));
  el.push(HL(TABLE.x + 1, TABLE.y + 2, TABLE.w - 2, C.dim));
  // uprights + linear rails
  for (const u of UPR) {
    el.push(...box(u.x, UPR_TOP, u.w, TABLE.y - UPR_TOP + 1, C.line));
    el.push(VL(u.x + 2, UPR_TOP + 2, TABLE.y - UPR_TOP - 3, C.dim));
  }
  // crossbeam
  el.push(...box(BEAM.x, BEAM.y, BEAM.w, BEAM.h, C.line));
  el.push(HL(BEAM.x + 1, BEAM.y + 2, BEAM.w - 2, C.dim));
  // top canopy line
  el.push(HL(BEAM.x, UPR_TOP, BEAM.w, C.line));
  return React.createElement('g', null, el);
}

function Slab({ cutTo, dx }) {
  const el = [];
  const x0 = SLAB.x, x1 = SLAB.x + SLAB.w - 1, top = SLAB.y, bot = SLAB.y + SLAB.h - 1;
  if (cutTo == null) {
    el.push(HL(x0, top, SLAB.w, C.wood));
  } else {
    const to = Math.max(CUT_FROM, Math.min(CUT_TO, cutTo));
    el.push(HL(x0, top, CUT_FROM - x0 + 1, C.wood));
    el.push(VL(CUT_FROM, top, KERF_Y - top + 1, C.wood));
    el.push(HL(CUT_FROM, KERF_Y, to - CUT_FROM + 1, C.woodDim));
    el.push(VL(to, top, KERF_Y - top + 1, C.wood));
    el.push(HL(to, top, x1 - to + 1, C.wood));
  }
  el.push(VL(x0, top, SLAB.h, C.wood), VL(x1, top, SLAB.h, C.wood));
  el.push(HL(x0, bot, SLAB.w, C.woodDim));
  return React.createElement('g', { transform: `translate(${qp(dx || 0)} 0)` }, el);
}

function Head({ bx, zBottom, spin, accent }) {
  const el = [];
  const cx0 = bx - 5;
  // carriage riding the beam
  el.push(...box(cx0, BEAM.y - 2, 11, 10, C.line));
  el.push(HL(cx0 + 1, BEAM.y + 5, 9, C.dim));
  el.push(HL(cx0 + 2, BEAM.y - 1, 2, accent), HL(cx0 + 7, BEAM.y - 1, 2, C.cyan, 0.9));
  // Z slide + spindle body
  el.push(VL(bx, SPIN_TOP - 3, 3, C.dim));
  el.push(...box(bx - 3, SPIN_TOP, 7, zBottom - SPIN_TOP, C.line));
  el.push(VL(bx, SPIN_TOP + 2, zBottom - SPIN_TOP - 4, C.dim));
  el.push(HL(bx - 4, zBottom - 3, 9, C.line));
  // collet + bit
  el.push(HL(bx - 1, zBottom, 3, C.line));
  el.push(VL(bx, zBottom + 1, 2, spin ? C.hot : C.line));
  return React.createElement('g', null, el);
}

function Spark({ bx, y, on, accent, t }) {
  if (!on) return null;
  const f = 0.5 + 0.5 * Math.sin(t * 11);
  return React.createElement('g', null, [
    VL(bx, y - 1, 2, f > 0.5 ? C.hot : accent),
    HL(bx - 1, y, 3, C.hot, 0.35 + 0.45 * f),
  ]);
}

const hash = (n) => { const s = Math.sin(n * 127.1 + 311.7) * 43758.5453; return s - Math.floor(s); };

function Chips({ p, count }) {
  if (!count) return null;
  const life = 0.07, out = [];
  for (let k = 0; k < count; k++) {
    const spawn = (k / count) * (1 + life);
    const a = (p - spawn) / life;
    if (a < 0 || a > 1) continue;
    const x0 = bitXAtU(cutU(Math.min(1, spawn)));
    const vx = (hash(k) - 0.5) * 10;
    const arc = -6 - hash(k + 9) * 3;
    out.push(PT(qp(x0 + vx * a), qp(KERF_Y - 2 + arc * a + 10 * a * a),
      k % 3 === 0 ? C.yellow : C.wood, 1 - a * 0.5));
  }
  return React.createElement('g', null, out);
}

function Scanlines() {
  const el = [];
  for (let y = 0; y < G; y += 2) el.push(HL(0, y, G, '#000', 0.16));
  return React.createElement('g', null, el);
}

/* ── the persistent stage ───────────────────────────────────────────────── */

function Machine(props) {
  const { cam, bx, zBottom, spin, spark, cutTo, chipsP, chipCount,
          slabDX, newSlabDX, showNew, tweaks, t } = props;
  _k = 0;
  return (
    <svg width="100%" height="100%" viewBox={viewBox(cam)} shapeRendering="crispEdges"
         style={{ display: 'block', background: C.bg }}>
      <rect x={0} y={0} width={G} height={G} fill={C.bg} />
      <defs>
        <clipPath id="stockclip">
          <rect x={UPR[0].x + 4} y={SLAB.y - 4} width={UPR[1].x - UPR[0].x - 4} height={SLAB.h + 5} />
        </clipPath>
      </defs>
      <Frame />
      <g clipPath="url(#stockclip)">
        <Slab cutTo={cutTo} dx={slabDX} />
        {showNew && <Slab cutTo={null} dx={newSlabDX} />}
      </g>
      <Chips p={chipsP} count={chipCount} />
      <Head bx={bx} zBottom={zBottom} spin={spin} accent={tweaks.accent} />
      {tweaks.glow && <Spark bx={bx} y={zBottom + 2} on={spark} accent={tweaks.accent} t={t} />}
      {tweaks.scanlines && <Scanlines />}
    </svg>
  );
}

const TweakCtx = React.createContext({ accent: C.orange, chips: 0, glow: true, scanlines: true });
const useT = () => React.useContext(TweakCtx);

/* ── scenes ─────────────────────────────────────────────────────────────── */

function Approach() {
  const { progress: p, localTime } = useScene();
  const tweaks = useT();
  const bx = qp(lerp(HOME_X, CUT_FROM, Easing.easeInOutCubic(clamp((p - 0.12) / 0.48, 0, 1))));
  const plunge = Easing.easeInOutCubic(clamp((p - 0.62) / 0.36, 0, 1));
  const zBottom = qp(lerp(Z_UP, Z_DOWN, plunge));
  const cam = lerpCam(HOME_CAM, cutCam(0), Easing.easeInOutCubic(clamp((p - 0.08) / 0.92, 0, 1)));
  return (
    <Machine cam={cam} bx={bx} zBottom={zBottom} spin={p > 0.5} spark={plunge > 0.55}
             cutTo={plunge >= 1 ? CUT_FROM : null} chipsP={-1} chipCount={0}
             slabDX={0} newSlabDX={0} showNew={false} tweaks={tweaks} t={localTime} />
  );
}

function Cut() {
  const { progress: p, localTime } = useScene();
  const tweaks = useT();
  const bx = bitXAtU(cutU(p));
  return (
    <Machine cam={cutCam(p)} bx={bx} zBottom={Z_DOWN} spin spark
             cutTo={bx} chipsP={p} chipCount={tweaks.chips}
             slabDX={0} newSlabDX={0} showNew={false} tweaks={tweaks} t={localTime} />
  );
}

function Eject() {
  const { progress: p, localTime } = useScene();
  const tweaks = useT();
  const rise = Easing.easeInOutCubic(clamp(p / 0.24, 0, 1));
  const zBottom = qp(lerp(Z_DOWN, Z_UP, rise));
  const back = Easing.easeInOutCubic(clamp((p - 0.5) / 0.42, 0, 1));
  const bx = qp(lerp(CUT_TO, HOME_X, back));
  const feed = Easing.easeInOutCubic(clamp((p - 0.3) / 0.42, 0, 1));
  const cam = lerpCam(cutCam(1), HOME_CAM, Easing.easeInOutCubic(clamp((p - 0.06) / 0.4, 0, 1)));
  return (
    <Machine cam={cam} bx={bx} zBottom={zBottom} spin={p < 0.3} spark={p < 0.12}
             cutTo={CUT_TO} chipsP={-1} chipCount={0}
             slabDX={-feed * 46} newSlabDX={(1 - feed) * 46} showNew={feed > 0}             tweaks={tweaks} t={localTime} />
  );
}

/* ── root ───────────────────────────────────────────────────────────────── */

function CncRoot() {
  const [tw, setTweak] = useTweaks(window.TWEAK_DEFAULTS || {});
  const tweaks = {
    accent: tw.accent || C.orange,
    chips: tw.chips == null ? 12 : tw.chips,
    glow: tw.glow !== false,
    scanlines: tw.scanlines !== false,
  };
  return (
    <div style={{ position: 'absolute', inset: 0, background: '#000' }}>
      <TweakCtx.Provider value={tweaks}>
        <SceneStage width={SIZE} height={SIZE} scenes={window.OM_SCENES}
                    playback={window.OM_PLAYBACK} bg="#000000">
          {{ Approach, Cut, Eject }}
        </SceneStage>
      </TweakCtx.Provider>
      <TweaksPanel>
        <TweakSection label="Machine" />
        <TweakColor label="Accent" value={tweaks.accent}
                    options={[C.orange, C.cyan, C.yellow, '#3DDC84']}
                    onChange={(v) => setTweak('accent', v)} />
        <TweakSlider label="Chip spray" value={tweaks.chips} min={0} max={40}
                     onChange={(v) => setTweak('chips', v)} />
        <TweakToggle label="Spindle spark" value={tweaks.glow}
                     onChange={(v) => setTweak('glow', v)} />
        <TweakSection label="Screen" />
        <TweakToggle label="Scanlines" value={tweaks.scanlines}
                     onChange={(v) => setTweak('scanlines', v)} />
        <TweakToggle label="Motion editor" value={tw.motionEditor !== false}
                     onChange={(v) => setTweak('motionEditor', v)} />
      </TweaksPanel>
    </div>
  );
}

window.CncRoot = CncRoot;
